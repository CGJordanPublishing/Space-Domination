Space domination was created on LaTeX a6paper and is designed to be printed on a6, a5, or 5.5"x8.5" paper.
space-domination.pdf is the file that contains the printable game.
